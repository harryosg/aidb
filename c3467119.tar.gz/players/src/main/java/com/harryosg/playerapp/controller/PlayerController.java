package com.harryosg.playerapp.controller;

import com.harryosg.playerapp.domain.PlayerEntry;
import com.harryosg.playerapp.service.PlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping ("/api")
@RestController
public class PlayerController {

    @Autowired
    private PlayerService playerService;

    @GetMapping ("/comments")
    public List <PlayerEntry> getAllComments () {
        return playerService.findAllEntries ();
    }

    @GetMapping ("/comment/{id}")
    public PlayerEntry findGuestBookEntryById (@PathVariable("id") Integer id) {
        return this.playerService.findPlayerEntryById(id);
    }

    @DeleteMapping("/comment/{id}")
    public void deleteGuestBookEntryById (@PathVariable ("id") Integer id) {
        this.playerService.deletePlayerEntryById(id);
    }

    @GetMapping ("/user/{user}")
    public List <PlayerEntry> findGuestBookEntryByUser (@PathVariable ("user") String user) {
        return this.playerService.findPlayerEntryByUser(user);
    }

    @PostMapping ("/add")
    public void addComment (@RequestBody PlayerEntry playerEntry) {
        this.playerService.save (playerEntry);
    }

    @PostMapping ("/update")
    public void updateComment (@RequestBody PlayerEntry playerEntry) {
        this.playerService.save (playerEntry);
    }

}
